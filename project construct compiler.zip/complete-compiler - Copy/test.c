int x = 10;
int y = 5;
int z = x * y;
printf("The output of x + y =", z);